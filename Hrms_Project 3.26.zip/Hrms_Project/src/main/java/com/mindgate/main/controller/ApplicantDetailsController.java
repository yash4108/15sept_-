package com.mindgate.main.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.service.ApplicantDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("applicantdetailsapi")
public class ApplicantDetailsController {

	@Autowired
	private ApplicantDetailsServiceInterface applicantDetailsService;

	@RequestMapping(value = "ViewApplicant/{jobId}", method = RequestMethod.GET)
	public List<ApplicantDetails> ViewApplicant(@PathVariable int jobId) {

		return applicantDetailsService.ViewApplicant(jobId);

	}

	@RequestMapping(value = "addapplicant", method = RequestMethod.POST)
	public boolean addNewApplicant(@RequestBody ApplicantDetails applicantDetails) {
		System.out.println(applicantDetails);
		return applicantDetailsService.addNewApplicant(applicantDetails);
	}

	@RequestMapping(value = "updateapplicantstaus", method = RequestMethod.PUT)
	public boolean updateApplicantStatus(@RequestBody ApplicantDetails applicantDetails) {
		return applicantDetailsService.updateApplicantStatus(applicantDetails);

	}

	@RequestMapping(value = "getApplicant/{applicantId}", method = RequestMethod.GET)
	public ApplicantDetails getApplicant(@PathVariable int applicantId) {
		System.out.println("getApplicant");

		return applicantDetailsService.getApplicant(applicantId);

	}

	@RequestMapping(value = "getApplicantforhr", method = RequestMethod.GET)
	public List<ApplicantDetails> getApplicantForHr() {

		return applicantDetailsService.getApplicantForHr();
	}

	@RequestMapping(value = "updateapplicantstausinprocess", method = RequestMethod.PUT)
	public	boolean updateApplicantStatusInProcess(@RequestBody ApplicantDetails applicantDetails)
	{
		return applicantDetailsService.updateApplicantStatusInProcess(applicantDetails);

	}

	@RequestMapping(value = "updateapplicantstausselected", method = RequestMethod.PUT)
	public boolean updateApplicantStatusSelected(@RequestBody ApplicantDetails applicantDetails)
	{
		return applicantDetailsService.updateApplicantStatusSelected(applicantDetails);

	}
	
	@RequestMapping(value = "updateapplicantstaushired", method = RequestMethod.PUT)
	public boolean  updateApplicantStatusHired(@RequestBody ApplicantDetails applicantDetails)
	{
		return applicantDetailsService.updateApplicantStatusHired(applicantDetails);

	}
}
