package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.repository.ApplicantDetailsRepositoryInterface;

@Service
public class ApplicantDetailsService implements ApplicantDetailsServiceInterface {

	@Autowired
	private ApplicantDetailsRepositoryInterface ApplicantDetailsRepository;

	@Override
	public List<ApplicantDetails> ViewApplicant(int jobId) {

		return ApplicantDetailsRepository.ViewApplicant(jobId);

	}

	@Override
	public boolean addNewApplicant(ApplicantDetails applicantDetails) {
		System.out.println(applicantDetails);
		return ApplicantDetailsRepository.addNewApplicant(applicantDetails);
	}

	@Override
	public boolean updateApplicantStatus(ApplicantDetails applicantDetails) {
		// TODO Auto-generated method stub
		return ApplicantDetailsRepository.updateApplicantStatus(applicantDetails);
	}

	@Override
	public ApplicantDetails getApplicant(int applicantId) {
		System.out.println("getApplicant");
		return ApplicantDetailsRepository.getApplicant(applicantId);
	}

	@Override
	public List<ApplicantDetails> getApplicantForHr() {
		// TODO Auto-generated method stub
		return ApplicantDetailsRepository.getApplicantForHr();
	}

}
