package com.mindgate.main.service;

import com.mindgate.main.domain.SendEmail;

public interface EmailSenderServiceInterface {

	
	String sendSimpleMail(SendEmail sendEmail);

}
