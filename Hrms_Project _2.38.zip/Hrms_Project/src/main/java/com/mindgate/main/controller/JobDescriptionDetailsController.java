package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.service.JobDescriptionDetailsServiceInterface;
import com.mindgate.main.service.LoginDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("jobdescriptionapi")
public class JobDescriptionDetailsController {
	@Autowired
	private JobDescriptionDetailsServiceInterface jobDescriptionDetailsService;

	@RequestMapping(value = "getall", method = RequestMethod.GET)
	public List<JobDescriptionDetails> getAllDescription() {
		return jobDescriptionDetailsService.getAllDescription();

	}

	@RequestMapping(value = "getbyemployeeid/{employeeId}", method = RequestMethod.GET)
	public List<JobDescriptionDetails> getJobDescriptionByemployeeId(@PathVariable int employeeId) {
		return jobDescriptionDetailsService.getJobDescriptionByemployeeId(employeeId);
	}

	@RequestMapping(value = "getbyjobId/{jobId}", method = RequestMethod.GET)
	public JobDescriptionDetails getJobDescriptionByJobId(@PathVariable int jobId) {
		System.out.println(jobId);
		return jobDescriptionDetailsService.getJobDescriptionByJobId(jobId);
	}

	
	
	@RequestMapping(value = "addJob", method = RequestMethod.POST)
	public boolean addJobDescription(@RequestBody JobDescriptionDetails jobDescriptionDetails) {
		System.out.println(jobDescriptionDetails);
		return jobDescriptionDetailsService.addJobDescription(jobDescriptionDetails);
	}

	@RequestMapping(value = "getpendingrequests/{projectId}", method = RequestMethod.GET)
	public List<JobDescriptionDetails> getJobDescriptionByProjectId(@PathVariable String projectId) {
		return jobDescriptionDetailsService.getJobDescriptionByProjectId(projectId);
	}

	@RequestMapping(value = "updateJobStatus", method = RequestMethod.PUT)
	public boolean updateJobStatus(@RequestBody JobDescriptionDetails jobDescriptionDetails) {
		System.out.println(jobDescriptionDetails);
		return jobDescriptionDetailsService.updateJobStatus(jobDescriptionDetails);
	}

	@RequestMapping(value = "updateRequiredCandidate", method = RequestMethod.PUT)
	public boolean updateRequiredCandidate(@RequestBody JobDescriptionDetails jobDescriptionDetails) {
		System.out.println(jobDescriptionDetails);
		return jobDescriptionDetailsService.updateRequiredCandidate(jobDescriptionDetails);
	}
	

	@RequestMapping(value = "getApprovedDescription", method = RequestMethod.GET)
	public List<JobDescriptionDetails> getAllDescriptionApproved() {
		return jobDescriptionDetailsService.getAllDescriptionApproved();

	}
	
	@RequestMapping(value = "getPublishDescription", method = RequestMethod.GET)
	public List<JobDescriptionDetails> getAllDescriptionPublish(){
		System.out.println("in publish controller");
		return jobDescriptionDetailsService.getAllDescriptionPublish();

	}

}
