package com.mindgate.main.repository;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.mindgate.main.domain.ApplicantDetails;

public interface ApplicantDetailsRepositoryInterface {

	public List<ApplicantDetails> ViewApplicant(int jobId);

	public boolean addNewApplicant(ApplicantDetails applicantDetails);
	
	public boolean updateApplicantStatus(ApplicantDetails applicantDetails);

	public ApplicantDetails getApplicant(int applicantId);
	
	public List<ApplicantDetails>getApplicantForHr();

	public	boolean updateApplicantStatusInProcess(ApplicantDetails applicantDetails);
	
	public boolean updateApplicantStatusSelected(ApplicantDetails applicantDetails);

	
}
