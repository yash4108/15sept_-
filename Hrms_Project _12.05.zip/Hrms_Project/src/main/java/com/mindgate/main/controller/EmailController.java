package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.SendEmail;
import com.mindgate.main.service.EmailSenderService;
import com.mindgate.main.service.EmailSenderServiceInterface;

// Annotation
@RestController
// Class
public class EmailController {

	@Autowired
	private EmailSenderServiceInterface emailSenderService;

	// Sending a simple Email
	@PostMapping("/sendMail")
	public String sendMail(@RequestBody SendEmail sendEmail) {
		String status = emailSenderService.sendSimpleMail(sendEmail);

		return status;
	}

	@PostMapping("/sendMailWithAttachment")
	public String sendMailWithAttachment(@RequestBody SendEmail sendEmail) {
		String status = emailSenderService.sendMailWithAttachment(sendEmail);

		return status;
	}

}