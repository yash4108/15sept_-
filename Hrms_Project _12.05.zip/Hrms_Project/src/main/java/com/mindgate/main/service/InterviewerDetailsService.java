package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.InterviewerDetails;
import com.mindgate.main.repository.InterviewerDetailsRepositoryInterface;

@Service
public class InterviewerDetailsService implements InterviewerDetailsServiceInterface {

	@Autowired
    private InterviewerDetailsRepositoryInterface interviewerDetailsRepository;

	@Override
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		return interviewerDetailsRepository.addInterviewerDetails(interviewerDetails);
	}

	@Override
	public List<InterviewerDetails> getInterviewerDetailst(int employee_id) {
		// TODO Auto-generated method stub
		return interviewerDetailsRepository.getInterviewerDetailst(employee_id);
	}

	@Override
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails) {
		System.out.println(interviewerDetails);
		return interviewerDetailsRepository.updateInterviewerDetails(interviewerDetails);
	}

	@Override
	public InterviewerDetails getInterviewObject(int interviewId) {
		System.out.println("getInterviewObject");
		return interviewerDetailsRepository.getInterviewObject(interviewId);
	}

	
}